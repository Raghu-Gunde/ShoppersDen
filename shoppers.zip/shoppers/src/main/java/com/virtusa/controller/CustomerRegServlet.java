package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.daoImplementation.CustomerDaoImpl;
import com.virtusa.daoInterfaces.CustomerDao;
import com.virtusa.model.Customer;
/**
 * Servlet implementation class CustomerRegServlet
 */
public class CustomerRegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerRegServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Customer custom = new Customer();
		custom.setRoleId(2);
		custom.setName(request.getParameter("name"));
		custom.setAddress(request.getParameter("address"));
		custom.setEmail(request.getParameter("email"));
		custom.setPassword(request.getParameter("apassword"));
		custom.setPhoneNo(Long.parseLong(request.getParameter("aphoneno")));
		CustomerDao c = new CustomerDaoImpl();
		PrintWriter out = response.getWriter();
		int res=c.saveCustomerInfo(custom);
		if(res>0){
			out.println("<script>alert('Registred successfully');\nwindow.location.href='ShoppersHome.jsp'</script>");
		}
		else{
			out.println("<script>alert('Failed to Registred');\nwindow.location.href='ShoppersHome.jsp'</script>");
		}
	}

}
