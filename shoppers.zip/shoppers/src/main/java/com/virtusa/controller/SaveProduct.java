package com.virtusa.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.virtusa.daoImplementation.ProductDaoImpl;
import com.virtusa.daoInterfaces.ProductDao;
import com.virtusa.model.Product;

@WebServlet("/saveProduct")
@MultipartConfig(fileSizeThreshold=1024*1024*2, 
maxFileSize=1024*1024*10, 
maxRequestSize=1024*1024*50)

public class SaveProduct extends HttpServlet
{
	
	private String getFileName(final Part part) {
	    final String partHeader = part.getHeader("content-disposition");
	    
	    for (String content : part.getHeader("content-disposition").split(";")) {
	        if (content.trim().startsWith("filename")) {
	            return content.substring(
	                    content.indexOf('=') + 1).trim().replace("\"", "");
	        }
	    }
	    return null;
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter outObj = response.getWriter();
		
		try {
			int pid = Integer.parseInt(request.getParameter("pid"));
			String pname = request.getParameter("pname");
			String pdesc = request.getParameter("desc");
			double price = Double.parseDouble(request.getParameter("price"));
			String bname = request.getParameter("bname");
            int stock = Integer.parseInt( request.getParameter("stock"));
            Part filePart = request.getPart("image");
            String category = request.getParameter("category");
            
            String finalPath="";
            String path = "F:/Eclipse oxygen/shoppers/src/main/webapp/produt_images";
            /*  String path= f.getAbsolutePath();
            path = path.replace("\\", "/");*/
            File file = new File(path);
            String fileName = getFileName(filePart);
            
            OutputStream out = null;
            
            InputStream filecontent = null;
              
            out = new FileOutputStream(new File(path + File.separator + fileName));
          
            filecontent = filePart.getInputStream();
       
   
            int read = 0;
            final byte[] bytes = new byte[1024 * 2];
   
            while ((read = filecontent.read(bytes)) != -1) {
            	out.write(bytes, 0, read);             
              finalPath="produt_images"+"/"+fileName;            
            }	
            
            out.flush();
            out.close();
            
           Product product = new Product();
           product.setBrandName(bname);
           product.setImage(finalPath);
           product.setProductDesc(pdesc);
           product.setProductId(pid);
           product.setProductPrice(price);
           product.setProductName(pname);
           product.setStock(stock);
           product.setCategory(category);
           
          ProductDao dao = new ProductDaoImpl();
          int res = dao.saveProductInfo(product);
          if(res>0){
  				outObj.println("<script>alert('Product Saved successfully');\nwindow.location.href='Home.html'</script>");
	  		}
	  		else{
	  			outObj.println("<script>alert('Failed to save Product');\nwindow.location.href='Home.html'</script>");
	  		}
           
           
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
	
	}
}
