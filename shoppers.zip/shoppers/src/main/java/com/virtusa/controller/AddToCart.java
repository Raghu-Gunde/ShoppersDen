package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.helper.MySqlHelper;

/**
 * Servlet implementation class AddToCart
 */
public class AddToCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToCart() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		if(session.getAttribute("usession")==null)
			out.print("<script>alert('login is required to add products to your cart');\nwindow.location.href='ShoppersHome.jsp'</script>");
		else{
			int pid = Integer.parseInt(request.getParameter("pid"));
			System.out.println(pid);
			int qty = Integer.parseInt(request.getParameter("quantity"));	
			System.out.println(qty);
			try {
				Connection conn = MySqlHelper.getConnection();
				String sql ="select * from productteam1 where productId ="+pid;		
					PreparedStatement ps =conn.prepareStatement(sql);
					ResultSet rs = ps.executeQuery();
					rs.next();
					int stock= rs.getInt(6);
					System.out.println(stock);
					if(stock>0){
						out.print("<script>alert('Unable to add to cart as product stock is not available');\nwindow.location.href='getProductInfo.jsp'</script>");
					}
					else{
						PreparedStatement upd =conn.prepareStatement("update productteam1 set stock='"+(stock-1)+"' where productId="+pid);
					    int i = upd.executeUpdate();
					    
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		}
		
	}

}
