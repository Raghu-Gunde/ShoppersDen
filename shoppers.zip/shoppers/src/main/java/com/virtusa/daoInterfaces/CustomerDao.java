package com.virtusa.daoInterfaces;

import com.virtusa.model.Customer;

public interface CustomerDao {

	public int saveCustomerInfo(Customer custom);
	public Customer getCustomerInfo(long phone);
}
