package com.virtusa.daoInterfaces;

import com.virtusa.model.Product;

public interface ProductDao 
{
	public int saveProductInfo(Product product);
}
