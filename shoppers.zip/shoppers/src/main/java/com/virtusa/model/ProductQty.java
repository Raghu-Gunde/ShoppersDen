package com.virtusa.model;

public class ProductQty {
     private int productQtyId;
     private int productId;
     private int cartId;
     private int categoryId;
     private int qty;
     private double amount;
	public int getProductQtyId() {
		return productQtyId;
	}
	public void setProductQtyId(int productQtyId) {
		this.productQtyId = productQtyId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
     
     
}
