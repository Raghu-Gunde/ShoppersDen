package com.virtusa.daoImplementation;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.virtusa.daoInterfaces.CustomerDao;
import com.virtusa.helper.MySqlHelper;
import com.virtusa.model.Customer;

public class CustomerDaoImpl implements CustomerDao{

	

	@Override
	public int saveCustomerInfo(Customer custom) {
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
		    Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/shop","root","raghu000");
		    String sql="insert into userteam1 values(?,?,?,?,?,?)";		    
		    PreparedStatement ps = conn.prepareStatement(sql);
		    ps.setInt(1, custom.getRoleId());
		    ps.setString(2, custom.getName());
		    ps.setString(4, custom.getEmail());
		    ps.setString(3, custom.getAddress());
		    ps.setString(5, custom.getPassword());
		    ps.setLong(6, custom.getPhoneNo());
		    int i = ps.executeUpdate();
		    return i;
		}catch(Exception se){
			System.out.println("Message  :" +se.getMessage());
			return 0;
		}

		
	}

	@Override
	public Customer getCustomerInfo(long phone) {
		// TODO Auto-generated method stub
		
		try {
			Connection conn = MySqlHelper.getConnection();
			String sql ="select * from userteam1 where phoneNo="+phone+";";
			Statement st = conn.createStatement();
			ResultSet rs =st.executeQuery(sql);
			if(rs.next()){
				Customer cust = new Customer();
				cust.setRoleId(rs.getInt(1));
				cust.setName(rs.getString(2));
				cust.setAddress(rs.getString(3));
				cust.setEmail(rs.getString(4));
				cust.setPassword(rs.getString(5));
				cust.setPhoneNo(rs.getLong(6));
			    return cust;
			}
	    
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
