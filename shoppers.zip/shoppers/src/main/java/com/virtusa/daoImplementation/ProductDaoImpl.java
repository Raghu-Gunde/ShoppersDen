package com.virtusa.daoImplementation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.virtusa.daoInterfaces.ProductDao;
import com.virtusa.model.Product;

public class ProductDaoImpl implements ProductDao
{

	@Override
	public int saveProductInfo(Product product) 
	{
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
		    Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/shop","root","raghu000");
		    String sql="insert into productteam1 values(?,?,?,?,?,?,?,?)";		    
		    PreparedStatement ps = conn.prepareStatement(sql);
		    ps.setInt(1, product.getProductId());
		    ps.setString(2, product.getProductName());
		    ps.setString(3, product.getProductDesc());
		    ps.setDouble(5, product.getProductPrice());
		    ps.setString(4, product.getBrandName());
		    ps.setInt(6, product.getStock());
		    ps.setString(7, product.getImage());
		    ps.setString(8, product.getCategory());
		    int i = ps.executeUpdate();
		    return i;
		}catch(Exception se){
			System.out.println("Message  :" +se.getMessage());
			return 0;
		}
	}

}
