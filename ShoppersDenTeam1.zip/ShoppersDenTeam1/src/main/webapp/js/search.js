
window.addEventListener('load',function(){

var form = document.getElementById("searchForm");
            
            form.addEventListener("submit",function(){
            	var xhr=null;
   	         //create ajax object  	          
   	          try
   	          {
   	        	  xhr= new XMLHttpRequest(); //chrome,safari,firefox  	        	  
   	          }
   	          catch(err)
   	          {
   	        	  try
   	        	  {
   	        	  xhr = new ActiveXObject("MSXML2.XMLHttp.6.0"); //IE
   	        	  }
   	        	  catch(err)
   	        	  {
   	        		  console.log("Ajax Object not created");
   	        	  }
   	          }
   	          //Ajax Event handling 
   	         //once response received from server
   	         xhr.onreadystatechange = function()
   	          {
   	        	  alert("Entering...");
   	        	  var response=null;
   	        	  if (xhr.readyState == 4)//successful response
   	        		  {
   	        		   response=xhr.responseText;
   	        		   alert(response);
   	        		  }      	
   	          }

   	          //open the connection

   	          xhr.open('post','SearchServlet',false);

   	          xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            	//read values from form
            	var firstname = document.getElementById("search").value;
            	
            	xhr.send("search="+search);
            	return false;
            });
                   
            
            return false;
        }

        )