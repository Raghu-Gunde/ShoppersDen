window.addEventListener('load',function()
        {
            var name = document.getElementById('name');
            name.oninvalid = function(event) {
                if(name.value === '')
                    event.target.setCustomValidity('cannot be empty');
                else if(name.validity.patternMismatch)
                   event.target.setCustomValidity('Name should only contain letters. e.g. Ajay');
                else
                    event.target.setCustomValidity('');
                return true;
            }
            var phno = document.getElementById('phno');
            phno.oninvalid = function(event) {
                if(phno.value === '')
                    event.target.setCustomValidity('cannot be empty');
                else if(phno.validity.patternMismatch)
                    event.target.setCustomValidity('Phone Number must contain 10 digits');
                else
                    event.target.setCustomValidity('');
                return true;
            }
            
            var form = document.getElementById("RegistrationForm");
            
            form.addEventListener("submit",function(){
            	var xhr=null;
   	         //create ajax object  	          
   	          try
   	          {
   	        	  xhr= new XMLHttpRequest(); //chrome,safari,firefox  	        	  
   	          }
   	          catch(err)
   	          {
   	        	  try
   	        	  {
   	        	  xhr = new ActiveXObject("MSXML2.XMLHttp.6.0"); //IE
   	        	  }
   	        	  catch(err)
   	        	  {
   	        		  console.log("Ajax Object not created");
   	        	  }
   	          }
   	          //Ajax Event handling 
   	         //once response received from server
   	         xhr.onreadystatechange = function()
   	          {
   	        	  alert("Entering...");
   	        	  var response=null;
   	        	  if (xhr.readyState == 4)//successful response
   	        		  {
   	        		   response=xhr.responseText;
   	        		   //alert(response);
   	        		   document.getElementById("result").innerHTML=response;
   	        		  }      	
   	          }

   	          //open the connection

   	          xhr.open('post','RegisterServlet',false);

   	          xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            	//read values from form
            	var name = document.getElementById("name").value;
            	var address = document.getElementById("address").value;            	            	
            	var email =document.getElementById("email").value;
            	var password =document.getElementById("password").value;
            	var phno = document.getElementById("phno").value;
            	xhr.send("name="+name+"&phno="+phno+"&email="+email+"&password="+password+"&address="+address);
            	return false;
            });
                   
            
            return false;
        }

        )