package com.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.ecommerce.dao.implementaion.UserAccountImpl;
import com.virtusa.ecommerce.dao.interfaces.UserAccountDao;
import com.virtusa.ecommerce.models.UserAccount;

/**
 * Servlet implementation class ContactFormServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		Enumeration<String> enumeration=request.getParameterNames();
		response.setContentType("text/html");
		String name=null;
		UserAccount userAccount=new UserAccount();
		Hashtable<String,String> ht=new Hashtable<String,String>();
		while(enumeration.hasMoreElements())
		{
			name=enumeration.nextElement();
			out.println(name+":"+request.getParameter(name)+"<br/>");
			ht.put(name,request.getParameter(name));
		}
		userAccount.setAphoneno(Long.parseLong(ht.get("aphoneno")));
		userAccount.setFname(ht.get("name"));
		userAccount.setApassword(ht.get("apassword"));
		userAccount.setAddress(ht.get("address"));
		userAccount.setEmail(ht.get("email"));

			
		  UserAccountDao accountDao=new UserAccountImpl(); 
		  
		  boolean status=false; 
		  try {
		  status=accountDao.addUserAccount(userAccount);
		  if(!status)
		  {
			  out.println("record  is not added");
			  }
		  else
		  {
			  out.println("record is added");
			  } 
		  
		  }
		  catch (SQLException e) 
		  { // TODO: handle exception
			  e.printStackTrace(); 
			  
		  }
		 
		
		
	}

}
