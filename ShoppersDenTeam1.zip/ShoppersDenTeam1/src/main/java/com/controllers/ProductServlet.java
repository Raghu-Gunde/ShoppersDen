package com.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.ecommerce.dao.implementaion.ProductImpl;
import com.virtusa.ecommerce.dao.interfaces.ProductDao;
import com.virtusa.ecommerce.models.Product;

/**
 * Servlet implementation class ProductServlet
 */
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String name=null;
		
		
		
		Enumeration<String> enumeration=request.getParameterNames();
		response.setContentType("text/html");
		Product product=new Product();
		Hashtable<String,String> ht=new Hashtable<String,String>();
		while(enumeration.hasMoreElements())
		{
			name=enumeration.nextElement();
			out.println(name+":"+request.getParameter(name)+"<br/>");
			ht.put(name,request.getParameter(name));
		}
		product.setProductId(Integer.parseInt(ht.get("productId")));
		product.setProductName(ht.get("productName"));
		product.setProductDesc(ht.get("productDesc"));
		product.setBrandName(ht.get("brandName"));
		product.setPrice(Float.parseFloat(ht.get("price")));
		product.setStock(Integer.parseInt(ht.get("stock")));
		product.setCategoryId(Integer.parseInt(ht.get("categoryId")));
		
		 Blob b = null;
		try {
			b = new javax.sql.rowset.serial.SerialBlob(ht.get("image").getBytes());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		product.setImage(b);
		
		ProductDao productDao=new ProductImpl();
		  boolean status=false; 
		 
		  try {
			status=productDao.addProduct(product);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  if(!status)
		  {
			  out.println("record  is not added");
			  }
		  else
		  {
			  out.println("record is added");
			  } 
		
		
		
	}

}
