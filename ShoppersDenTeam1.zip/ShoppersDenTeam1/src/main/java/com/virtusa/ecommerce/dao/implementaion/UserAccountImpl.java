package com.virtusa.ecommerce.dao.implementaion;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.virtusa.ecommerce.dao.interfaces.UserAccountDao;
import com.virtusa.ecommerce.helpers.MySqlHelper;
import com.virtusa.ecommerce.models.UserAccount;

public class UserAccountImpl implements UserAccountDao 
{
	private Connection conn;
	private CallableStatement callable;
	private PreparedStatement pre;
	public boolean addUserAccount(UserAccount useraccount)throws SQLException
	{
		conn=MySqlHelper.getConnection();
		int count=0;
		boolean status=false;
		try {
			callable=conn.prepareCall("{call adduserteam1(?,?,?,?,?,?)}");
			callable.setInt(1, useraccount.getRoleId());
			callable.setLong(6, useraccount.getAphoneno());
			callable.setString(2,useraccount.getFname());
			callable.setString(5, useraccount.getApassword());
			callable.setString(3,useraccount.getAddress());
			callable.setString(4, useraccount.getEmail());
			count=callable.executeUpdate();
			System.out.println(count);
			if(count>0)
				status=true;
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally
		{
			conn.close();
		}
		return status;
	}
	
}
