package com.virtusa.ecommerce.dao.implementaion;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.virtusa.ecommerce.dao.interfaces.ProductDao;
import com.virtusa.ecommerce.helpers.MySqlHelper;
import com.virtusa.ecommerce.models.Product;

public class ProductImpl  implements ProductDao{

	
	private Connection conn;
	private CallableStatement callable;
	private PreparedStatement pre;
	@Override
	public boolean addProduct(Product product) throws SQLException {
		// TODO Auto-generated method stub
		conn=MySqlHelper.getConnection();
	     int count=0;
	     boolean status=false;
	    try {
	     callable= conn.prepareCall("{call addproduct(?,?,?,?,?,?,?,?)}");
	     callable.setInt(1, product.getProductId());
	     callable.setString(2, product.getProductName());
	     callable.setString(3, product.getProductDesc());
	     callable.setString(4, product.getBrandName());
	     callable.setFloat(5, product.getPrice());
	     callable.setInt(6, product.getStock());
	     callable.setInt(7, product.getCategoryId());
	     callable.setBlob(8, product.getImage());
	   	count=callable.executeUpdate();
	if(count>0)
	    status=true;

	 

	}catch(SQLException e)
	    {
	     System.out.println("callable"+e.getMessage());
	    }
	    finally {
	        
	            conn.close();
	        
	    }
	    return status;
	}

}
