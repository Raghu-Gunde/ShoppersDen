package com.virtusa.ecommerce.models;

import java.sql.Date;

public class UserAccount 
{
	private int roleId;
	private long aphoneno;
	private String fname;
	private String apassword;
	private String email;
	private String address;
	
	public int getRoleId() {
		return 2;
	}

	public long getAphoneno() {
		return aphoneno;
	}

	public void setAphoneno(long aphoneno) {
		this.aphoneno = aphoneno;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getApassword() {
		return apassword;
	}

	public void setApassword(String apassword) {
		this.apassword = apassword;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	
}
