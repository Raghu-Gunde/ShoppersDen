package com.virtusa.ecommerce.dao.interfaces;

import java.sql.SQLException;

import com.virtusa.ecommerce.models.Product;

public interface ProductDao 
{
public boolean addProduct(Product product) throws SQLException;
}
