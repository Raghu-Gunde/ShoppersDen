package com.virtusa.ecommerce.dao.interfaces;

import java.sql.SQLException;

import com.virtusa.ecommerce.models.UserAccount;

public interface UserAccountDao 
{
public boolean addUserAccount(UserAccount userAccount) throws SQLException;
}
